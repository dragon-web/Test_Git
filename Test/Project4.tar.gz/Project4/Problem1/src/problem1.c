#include "problem1.h"

int *bubble_prj4(FILE *fp_in) {
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below


	return dataset;
}

int *selection_prj4(FILE *fp_in) {
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below


	return dataset;
}

int *insertion_prj4(FILE *fp_in) {
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below


	return dataset;
}

int *heap_prj4(FILE *fp_in) {
  printf("heap");
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below

	
	return dataset;
}

int *merge_prj4(FILE *fp_in) {
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below

	return dataset;
}

void merge(int *dataset, int left, int mid, int right) {
	//Write your own code below
}



int *quick_prj4(FILE *fp_in) {
	int *dataset = (int*)malloc(sizeof(int)*SIZE);
	if (dataset == NULL) {
		printf("Mem alloc fail\n");
		return NULL;
	}
	fread(dataset, sizeof(int), SIZE, fp_in);
	//Write your own code below

	
	return dataset;
}

int partition(int *dataset, int low, int high) {
	//Write your own code below

}
